﻿// Homework 4 (part a)							Zakary Elseht	&	Changzong Liu
// elseht.z@husky.neu.edu 
// liu.changz@husky.neu.edu 
//
// Sudoku Puzzle (Part a), main source file
// Declarations and functions for project #4

#include <iostream>
#include <limits.h>
#include "d_matrix.h"
#include "d_except.h"
#include <list>
#include <fstream>

using namespace std;

typedef int ValueType; // The type of the value in a cell
const int Blank = -1;  // Indicates that a cell is blank
int getSquare(int row, int col); // declaration


const int SquareSize = 3;  //  The number of cells in a small square
						   //  (usually 3).  The board has
						   //  SquareSize^2 rows and SquareSize^2
						   //  columns.

const int BoardSize = SquareSize * SquareSize;

const int MinValue = 1;
const int MaxValue = 9;

int numSolutions = 0;

class board
	// Stores the entire Sudoku board
{
public:
	board(int);
	void updateConflicts(int, int, int input = Blank);
	void clear();
	void clearCell(int, int);
	bool fillCell(int, int, int);
	void printConflicts();
	void initialize(ifstream &fin);
	void print();
	bool isBlank(int, int);
	bool isSolved();
	ValueType getCell(int, int);

private:

	// The following matrices go from 1 to BoardSize in each
	// dimension, i.e., they are each (BoardSize+1) * (BoardSize+1)
	matrix<ValueType> value;
	// bool vector for each row, column, and square
	matrix<bool> b_row, b_col, b_sqr;


};

board::board(int sqSize)
	: value(BoardSize + 1, BoardSize + 1)
	, b_row(BoardSize + 1, BoardSize + 1)
	, b_col(BoardSize + 1, BoardSize + 1)
	, b_sqr(BoardSize + 1, BoardSize + 1)
	// Board constructor
{

	clear();
}
bool board::isSolved()
{
	for (int i = 1; i <= BoardSize; i++)
		for (int j = 1; j <= BoardSize; j++)
		{
			if (value[i][j] == Blank)
				return false;
		}
	return true;
}
void board::clearCell(int row, int col)
{
	int removing = value[row][col];
	value[row][col] = Blank;
	updateConflicts(row, col, removing);
}
bool board::fillCell(int row, int col, int val)
{
	if (b_col[col][val])
		return false;
	if (b_row[row][val])
		return false;
	if (b_sqr[getSquare(row, col)][val])
		return false;
	value[row][col] = val;
	updateConflicts(row, col);

	return true;
}
void board::updateConflicts(int row, int col, int input)
{
	// update squares 
	// update columns
	// update row
	// check given row column and square for values and mark those in conflicts

	if (input == Blank)
	{
		b_row[row][value[row][col]] = true;
		b_col[col][value[row][col]] = true;
		b_sqr[getSquare(row, col)][value[row][col]] = true;
	}
	else
	{
		//cout << input << endl;
		b_row[row][input] = false;
		b_col[col][input] = false;
		b_sqr[getSquare(row, col)][input] = false;
	}

}

void board::printConflicts()
{

	cout << "Row Conflixts: ";
	for (int i = 1; i <= BoardSize; i++)
	{
		cout << endl;
		cout << "row " << i << " Values: ";
		for (int j = 1; j <= BoardSize; j++)
			if (b_row[i][j])
				cout << j << " ";
	}
	cout << endl << endl << "Column Conflixts: ";
	for (int i = 1; i <= BoardSize; i++)
	{
		cout << endl;
		cout << "col " << i << " Values: ";
		for (int j = 1; j <= BoardSize; j++)
			if (b_col[i][j])
				cout << j << " ";
	}
	cout << endl << endl << "Square Conflixts: ";
	for (int i = 1; i <= BoardSize; i++)
	{
		cout << endl;
		cout << "sqr " << i << " Values: ";
		for (int j = 1; j <= BoardSize; j++)
			if (b_sqr[i][j])
				cout << j << " ";
	}
	cout << endl;
	cout << "Solved status: "<< boolalpha <<isSolved() << endl << endl;
}
void board::clear()
// Mark all possible values as legal for each board entry
{
	for (int i = 1; i <= BoardSize; i++)
		for (int j = 1; j <= BoardSize; j++)
		{
			value[i][j] = Blank;
			b_row[i][j] = false;
			b_col[i][j] = false;
			b_sqr[i][j] = false;
		}
}

void board::initialize(ifstream &fin)
// Read a Sudoku board from the input file.
{
	char ch;

	clear();
	for (int i = 1; i <= BoardSize; i++)
		for (int j = 1; j <= BoardSize; j++)
		{
			fin >> ch;

			// If the read char is not Blank
			if (ch != '.')
			{
				//setCell(i, j, ch - '0');   // Convert char to int
				value[i][j] = (ch - '0');
				updateConflicts(i, j);
			}
		}
}

int squareNumber(int i, int j)
// Return the square number of cell i,j (counting from left to right,
// top to bottom.  Note that i and j each go from 1 to BoardSize
{
	// Note that (int) i/SquareSize and (int) j/SquareSize are the x-y
	// coordinates of the square that i,j is in.  

	return SquareSize * ((i - 1) / SquareSize) + (j - 1) / SquareSize + 1;
}

ostream &operator<<(ostream &ostr, vector<int> &v)
// Overloaded output operator for vector class.
{
	for (int i = 0; i < v.size(); i++)
		ostr << v[i] << " ";
	cout << endl;
	return ostr;
}

ValueType board::getCell(int i, int j)
// Returns the value stored in a cell.  Throws an exception
// if bad values are passed.
{
	if (i >= 1 && i <= BoardSize && j >= 1 && j <= BoardSize)
		return value[i][j];
	else
		throw rangeError("bad value in getCell");
}

bool board::isBlank(int i, int j)
// Returns true if cell i,j is blank, and false otherwise.
{
	if (i < 1 || i > BoardSize || j < 1 || j > BoardSize)
		throw rangeError("bad value in setCell");

	return (getCell(i, j) == Blank);
}

void board::print()
// Prints the current board.
{
	for (int i = 1; i <= BoardSize; i++)
	{
		if ((i - 1) % SquareSize == 0)	// Rows
		{
			cout << " -";
			for (int j = 1; j <= BoardSize; j++)
				cout << "---";
			cout << "-";
			cout << endl;
		}
		for (int j = 1; j <= BoardSize; j++)
		{
			if ((j - 1) % SquareSize == 0)	// Columns
				cout << "|";
			if (!isBlank(i, j))
				cout << " " << getCell(i, j) << " ";
			else
				cout << "   ";
		}
		cout << "|";
		cout << endl;
	}

	cout << " -";
	for (int j = 1; j <= BoardSize; j++)
		cout << "---";
	cout << "-";
	cout << endl;

}

int main()
{
	ifstream fin;
	int n_recursisions = 0, n_puzzles = 0;
	// Read the sample grid from the file.
	string fileName[] = { "sudoku1.txt","sudoku2_new.txt","sudoku3_new.txt" };
	for (int i = 0; i < 3; i++)
	{
		fin.open(fileName[i].c_str());
		if (!fin)
		{
			cerr << "Cannot open " << fileName << endl;
			exit(1);
		}

		try
		{
			board b1(SquareSize);

			while (fin && fin.peek() != 'Z')
			{
				b1.initialize(fin);
				b1.print();
				b1.printConflicts();
			}
		}
		catch (indexRangeError &ex)
		{
			cout << ex.what() << endl;
			cin.ignore();
			exit(1);
		}
		fin.close();
	}

	cin.ignore();
}
int getSquare(int row, int col)
{
	int x = (row - 1) / SquareSize; // 1, 2, or 3 
	int y = (col + 2) / SquareSize;
	int sqr = (x) * 3 + y;
	return sqr;
}